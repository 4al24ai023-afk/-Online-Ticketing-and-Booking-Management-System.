# 🎟️ SMARTTICKET — Online Ticketing & Booking Management System

> **Hackathon Submission for Problem Statement PS-07**  
> Complete high-concurrency event ticketing platform featuring real-time anti-overbooking inventory management, tamper-proof cryptographic QR passes, live camera ticket scanner, dual **React Web** and native **Flutter Android** mobile apps, and an atomic **Firebase Firestore** backend.

## Quick Start
```bash
# Web application
npm install
npm run dev

# Flutter Android application
cd flutter_smartticket
flutter pub get
flutter run -d android
```
